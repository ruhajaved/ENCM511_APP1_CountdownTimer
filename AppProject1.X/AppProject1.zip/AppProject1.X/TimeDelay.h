#ifndef TIMEDELAY_H
#define	TIMEDELAY_H

#include <xc.h> // include header file xc.h

void delay_ms(uint16_t); //function prototype for delay_ms

#endif

