 
#ifndef IOs_H
#define	IOs_H

#include <xc.h>     // include header file xc.h

void IOinit();    // function declaration for IOinit function
void IOcheck();   // function declaration for IOcheck function
void decrement(); // function declaration for decrement() function
void print_m_s(); // function declaration for print_m_s() function

#endif

